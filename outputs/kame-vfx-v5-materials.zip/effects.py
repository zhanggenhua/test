from math import cos, pi, sin
from random import Random

from PIL import Image, ImageDraw, ImageFilter


AA = 3


class EnergyCel:
    def __init__(self, size):
        self.size = size
        self.image = Image.new("RGBA", tuple(value * AA for value in size))
        self.draw = ImageDraw.Draw(self.image)

    def points(self, points):
        return [(round(x * AA), round(y * AA)) for x, y in points]

    def ellipse(self, center, radius, fill):
        x, y = center
        bounds = self.points(((x - radius, y - radius), (x + radius, y + radius)))
        self.draw.ellipse(bounds, fill=fill)

    def line(self, points, fill, width=1):
        self.draw.line(self.points(points), fill=fill, width=max(1, round(width * AA)))

    def polygon(self, points, fill):
        self.draw.polygon(self.points(points), fill=fill)

    def finish(self, glow=4):
        if glow:
            blur = self.image.filter(ImageFilter.GaussianBlur(glow * AA))
            blur.alpha_composite(self.image)
            return blur.resize(self.size, Image.Resampling.LANCZOS)
        return self.image.resize(self.size, Image.Resampling.LANCZOS)


def charge(size, center, radius, phase):
    cel = EnergyCel(size)
    x, y = center
    for multiplier, color in [
        (1.5, (37, 136, 255, 68)),
        (1.12, (53, 202, 255, 182)),
        (0.84, (135, 235, 255, 238)),
        (0.56, (250, 255, 255, 255)),
    ]:
        cel.ellipse(center, radius * multiplier, color)
    for index in range(8):
        direction = index * pi / 4 + phase * 0.32
        outer = radius + 11 + (index * 7 + phase * 11) % 15
        inner = outer - 4 - (index % 3) * 2
        start = (x + outer * cos(direction), y + outer * sin(direction))
        end = (x + inner * cos(direction), y + inner * sin(direction))
        cel.line((start, end), (146, 230, 255, 205), 1.3)
    for side in (-1, 1):
        for idx in range(7):
            angle = idx * 0.36 + phase * 0.17 + side * pi / 2
            distance = radius + 4 + 3 * sin(idx * 0.54 + phase)
            pt = (x + distance * cos(angle), y + distance * sin(angle))
            cel.ellipse(pt, 1.15 if idx % 3 else 1.65, (164, 235, 255, 205))
    return cel.finish(3)


def beam(size, center, length, radius, phase, power=1.0):
    cel = EnergyCel(size)
    x, y = center
    rng = Random(3618 + phase)

    def band(width, color, amplitude, start, end, shift=0):
        upper, lower = [], []
        for i in range(18):
            unit = i / 17
            xx = x + start + unit * (end - start)
            profile = (0.56 + 0.78 * sin(pi * unit * 0.84)) * (1 - 0.81 * unit**8)
            drift = sin(unit * 12 - phase * 0.9 + shift) * amplitude
            flare = (sin(unit * 41 - phase * 1.67 + shift) + cos(unit * 27 - shift)) * amplitude * 0.53
            upper.append((xx, y + drift - width * profile + flare))
            lower.append((xx, y + drift + width * profile - flare))
        cel.polygon(upper + lower[::-1], color)

    def tinted(rgb, opacity):
        return (*rgb, round(opacity * power))

    band(radius * 1.31, tinted((24, 98, 245), 129), radius * 0.16, 1, length)
    for sign in (-1, 1):
        for i in range(9):
            start = rng.uniform(0.01, 0.81)
            end = min(0.99, start + rng.uniform(0.08, 0.31))
            lift = sign * rng.uniform(0.72, 1.62) * radius
            cel.polygon([(x + start * length, y + lift * 0.64),
                         (x + (start + end) * length * 0.5, y + lift),
                         (x + end * length, y + lift * 1.1),
                         (x + (start + end) * length * 0.5, y + lift * 0.82)],
                        tinted((51, 171, 255), 182 if i % 2 else 228))
    band(radius, tinted((26, 173, 255), 248), radius * 0.12, 1, length - 2, 1)
    band(radius * 0.75, tinted((97, 228, 255), 250), radius * 0.105, 2, length - 3, 2)
    band(radius * 0.50, tinted((193, 247, 255), 255), radius * 0.065, 3, length - 6, 3)
    band(radius * 0.27, tinted((252, 255, 255), 255), radius * 0.038, 4, length - 11, 4)

    n = 14
    rays = []
    for i in range(n * 2):
        angle = i * pi / n
        scale = (0.62 if i % 2 else rng.uniform(1.24, 2.20)) * radius
        rays.append((x + scale * cos(angle), y + scale * sin(angle)))
    cel.polygon(rays, tinted((63, 202, 255), 195))
    cel.ellipse(center, radius * 0.81, tinted((137, 236, 255), 244))
    cel.ellipse((x + 2, y), radius * 0.56, tinted((248, 255, 255), 255))
    for i in range(11):
        particle_x = x + length * rng.uniform(0.16, 0.88)
        particle_y = y + radius * rng.uniform(-1.56, 1.56)
        span = rng.uniform(5, 19)
        cel.line(((particle_x, particle_y), (particle_x + span, particle_y - 0.8)),
                 tinted((174, 240, 255), 171), 1.2 if i % 3 else 2)
    return cel.finish(3.8)


def vanish(size, center, phase):
    cel = EnergyCel(size)
    x, y = center
    rng = Random(83)
    for i in range(14):
        angle = rng.uniform(-1.27, 1.27)
        distance = (7 + phase * 7) * rng.uniform(0.85, 2.6)
        pt = (x + distance * cos(angle), y + distance * sin(angle))
        cel.line((pt, (pt[0] + rng.uniform(1, 7), pt[1] - 0.5)),
                 (106, 223, 255, max(0, 215 - phase * 52)), 1.2 if i % 3 else 2)
    return cel.finish(2)
