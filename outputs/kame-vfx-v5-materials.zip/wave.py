import argparse
import json
from math import cos, pi, sin, tau
from pathlib import Path
from random import Random

from PIL import Image

from effects import EnergyCel


STEP = 1000 / 60
CHARGE = 70
RELEASE = 230
OUT = 500
OFF = 680
IMPACT_DELAY = 115
LENGTHS = (220, 335, 450)
BLUE = (23, 89, 246)
SKY = (41, 173, 255)
ICE = (154, 240, 255)
WHITE = (245, 255, 255)


def clamp(value):
    return max(0, min(1, value))


def smooth(value):
    value = clamp(value)
    return value * value * (3 - 2 * value)


def rgba(color, opacity):
    return (*color, round(255 * clamp(opacity)))


def polar(center, distance, angle):
    x, y = center
    return x + distance * cos(angle), y + distance * sin(angle)


def shard(cel, center, radius, span, angle, width, color):
    tip = polar(center, radius + span, angle)
    base = polar(center, radius, angle)
    shoulder = polar(center, radius + span * .25, angle)
    a = polar(shoulder, width, angle + pi / 2)
    b = polar(shoulder, width * .55, angle - pi / 2)
    cel.polygon((base, a, tip, b), color)


def orb(t):
    cel = EnergyCel((144, 144))
    center = (72, 72)
    growth = smooth(t / 155)
    radius = 3 + 10 * growth
    for scale, color, opacity in (
        (1.93, BLUE, .3), (1.44, SKY, .78), (1, ICE, .94), (.68, WHITE, 1)
    ):
        edge = [polar(center, radius * scale * (1 + .08 * sin(i + t / 39)), i * tau / 32)
                for i in range(32)]
        cel.polygon(edge, rgba(color, opacity))
    for i in range(12):
        flow = (t / 170 + i * .137) % 1
        angle = i * tau / 12 + .81 * flow
        distance = radius + 6 + (1 - flow) * (42 - 14 * growth)
        shard(cel, center, distance, 3 + 7 * flow, angle, 1.1, rgba(ICE, sin(pi * flow) * .8))
    return cel.finish(2.5)


def flash(t, impact=False):
    cel = EnergyCel((172, 164))
    center = (86, 82)
    progress = clamp(t / (180 if impact else 137))
    opacity = (1 - progress) ** 1.65
    radius = (12 if impact else 16) * (1 + .43 * sin(pi * progress)) * (1 - .73 * progress)
    if not impact:
        _, gain, visibility = beam_state(t, LENGTHS[-1])
        for i in range(7):
            angle = i * tau / 7 + .11 * sin(t / 81 + i * 2)
            shard(cel, center, 2, (9 + i % 3 * 4) * gain, angle, 1.45,
                  rgba(SKY, visibility * gain * .68))
        cel.ellipse(center, 9 * gain, rgba(SKY, visibility * gain * .9))
        cel.ellipse(center, 6.5 * gain, rgba(ICE, visibility * gain))
        cel.ellipse(center, 4.7 * gain, rgba(WHITE, visibility * gain))
    if opacity <= 0:
        return cel.finish(2.0)
    rng = Random(35 if impact else 29)
    for i in range(10 if impact else 12):
        angle = (i / 9 * pi - pi / 2 if impact else i * tau / 12) + rng.uniform(-.2, .2)
        extent = rng.uniform(17, 38) * (1 + progress * .49)
        width = rng.uniform(1.8, 6) * (1 - progress * .83)
        shard(cel, center, radius * .27, extent, angle, width, rgba(BLUE, .9 * opacity))
        shard(cel, center, radius * .35, extent * .83, angle, width * .48, rgba(ICE, opacity))
        if i % 3 == 0:
            shard(cel, center, extent + progress * 22, 7, angle, .85, rgba(ICE, opacity * .8))
    cel.ellipse(center, radius * 1.35, rgba(SKY, opacity * .8))
    cel.ellipse(center, radius, rgba(ICE, opacity))
    cel.ellipse(center, radius * .7, rgba(WHITE, opacity))
    return cel.finish(2.4)


def beam_state(t, length):
    front = min(length, length * (.12 + .88 * (1 - (1 - clamp(t / 102)) ** 1.6)))
    out = clamp((t - (OUT - RELEASE)) / (OFF - OUT))
    gain = (.53 + .47 * smooth(t / 82)) * (1 - smooth(out)) ** 1.23
    opacity = 1 - smooth((out - .38) / .62)
    return front, gain, opacity


def beam_sections(t, length):
    front, gain, opacity = beam_state(t, length)
    front = round(front)
    pivot = (42, 77)
    tip_pivot = 118
    width, height = length + 88, 154
    cel = EnergyCel((width, height))

    def shift(x):
        return (sin((x - t * .39) / 83) * 2.5 + sin(x / 23 - t / 63) * .8) * gain

    def reach(x, side, layer):
        foot = .46 + .61 * smooth(x / 130)
        swelling = sin((x - t * .46) / 57 + side) * .13 + sin(x / 30 - t / 44 + side) * .047
        taper_width = min(92 + layer * 4, front * .76)
        taper = clamp((front - x) / max(1, taper_width)) ** (.69 + layer * .04)
        return max(.24, foot + swelling) * taper

    def ribbon(layer, thickness, color, strength):
        step = max(8, (front + 2) // 3)
        x_axis = [front * i / step for i in range(step + 1)]
        upper = [(pivot[0] + x, pivot[1] + shift(x) - thickness * gain * reach(x, -1, layer))
                 for x in x_axis]
        lower = [(pivot[0] + x, pivot[1] + shift(x) + thickness * gain * reach(x, 1, layer))
                 for x in reversed(x_axis)]
        cel.polygon(upper + lower, rgba(color, strength * opacity))

    if gain > .011 and opacity > .01:
        for side, distance, rise, size, strength in (
            (-1, 89, 35, 83, .94), (1, 103, 34, 91, .90), (-1, 168, 27, 123, .84),
            (1, 225, 27, 102, .68), (-1, 316, 23, 142, .68),
        ):
            heel = front - distance + 6 * sin(t / 47 + distance)
            if heel < 9:
                continue
            x = pivot[0] + heel
            y = pivot[1] + shift(heel)
            span = min(size, front - heel + 9)
            spread = side * gain
            cel.polygon(((x, y + spread * 12), (x + span * .28, y + spread * rise),
                         (x + span, y + spread * (rise + 4)), (x + span * .73, y + spread * 13)),
                        rgba(BLUE, opacity * strength))
            cel.polygon(((x+8, y + spread * 14), (x+span*.39, y + spread * (rise-3)),
                         (x+span*.94, y + spread * (rise+3)), (x+span*.69, y + spread * 16)),
                        rgba(SKY, opacity * strength * .92))

        for i, (thickness, color, strength) in enumerate((
            (29, (18, 66, 179), .78), (24, BLUE, .98), (19, (26, 150, 255), 1),
            (14, (77, 210, 255), 1), (10, ICE, 1), (7.9, WHITE, 1),
        )):
            ribbon(i, thickness, color, strength)

        rng = Random(124)
        for i in range(12):
            side = 1 if i % 2 else -1
            lane = rng.uniform(14, 29)
            offset = rng.uniform(0, 495)
            streak = rng.uniform(15, 68)
            speed = rng.uniform(.39, .75)
            x = (offset + t * speed) % 495
            if x + streak >= front - 33:
                continue
            alpha = smooth(x / 55) * smooth((front - x - streak) / 70) * opacity
            y = pivot[1] + side * lane * gain
            x += pivot[0]
            cel.polygon(((x, y - side * 1.6), (x + streak * .29, y + side * 1.4 * gain),
                         (x + streak, y + side * 3.4 * gain), (x + streak * .61, y - side * 1.8)),
                        rgba(ICE if i % 3 else SKY, alpha * .55))
    combined = cel.finish(1.65)
    # Cut once in image space, preserving identical pixels at the join.
    join = pivot[0] + max(0, front - 66)
    body = Image.new("RGBA", combined.size)
    body.paste(combined.crop((0, 0, join, height)), (0, 0))
    tip = Image.new("RGBA", (192, height))
    tip_left = pivot[0] + front - tip_pivot
    tip.paste(combined.crop((join, 0, min(width, tip_left + tip.width), height)), (join - tip_left, 0))
    return body, tip


def times(duration):
    return [round(i * STEP) for i in range(round(duration / STEP))]


def make_tracks(length):
    hit = times(180)
    main = times(OFF - RELEASE)
    return {
        "charge": ((72, 72), times(RELEASE - CHARGE), RELEASE - CHARGE, orb),
        "muzzle": ((86, 82), main, OFF - RELEASE, flash),
        "body": ((42, 77), main, OFF - RELEASE, None),
        "tip": ((118, 77), main, OFF - RELEASE, None),
        "impact": ((86, 82), hit, 180, lambda t: flash(t, impact=True)),
    }


def render_tracks(length, names=None):
    rendered = {}
    beam_frames = [beam_sections(t, length) for t in times(OFF - RELEASE)]
    for name, (pivot, marks, duration, draw) in make_tracks(length).items():
        if names is not None and name not in names:
            continue
        if draw is None:
            frames = [pair[("body", "tip").index(name)] for pair in beam_frames]
        else:
            frames = [draw(t) for t in marks]
        if name in ("muzzle", "body", "tip", "impact"):
            frames.append(Image.new("RGBA", frames[0].size))
            marks = marks + [duration]
            duration += round(STEP)
        for frame in frames:
            bounds = frame.getchannel("A").getbbox()
            assert bounds is None or (bounds[0] > 0 and bounds[1] > 0
                                      and bounds[2] < frame.width and bounds[3] < frame.height), (name, bounds)
        positions = [round(beam_state(t, length)[0]) for t in marks] if name == "tip" else None
        rendered[name] = {
            "pivot": pivot, "times": marks, "duration_ms": duration, "frames": frames, "positions": positions
        }
    return rendered


def export(length, destination, tracks):
    destination.mkdir(parents=True, exist_ok=True)
    columns = 4
    manifest = {"facing": "right", "blend": "straight alpha", "length_px": length,
                "timeline_ms": {"charge": CHARGE, "release": RELEASE, "shrink": OUT, "clear": OFF,
                                "impact_delay": IMPACT_DELAY},
                "tracks": {}}
    for name, track in tracks.items():
        frames = track["frames"]
        width, height = frames[0].size
        atlas = Image.new("RGBA", (width * columns, height * ((len(frames) + columns - 1) // columns)))
        rows = []
        marks = track["times"] + [track["duration_ms"]]
        for i, frame in enumerate(frames):
            x, y = i % columns * width, i // columns * height
            atlas.paste(frame, (x, y))
            item = {"rect": [x, y, width, height], "duration_ms": marks[i+1] - marks[i]}
            if track["positions"] is not None:
                item["x_from_muzzle_px"] = track["positions"][i]
            rows.append(item)
        atlas.save(destination / f"{name}.png")
        manifest["tracks"][name] = {"atlas": f"{name}.png", "pivot_px": track["pivot"], "frames": rows}
    (destination / "motion.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--length", type=int, default=450, choices=range(150, 451), metavar="150..450")
    args = parser.parse_args()
    export(args.length, args.output, render_tracks(args.length))

