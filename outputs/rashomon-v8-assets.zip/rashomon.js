const WIDTH = 960;
const HEIGHT = 400;
const FPS = 30;
const DURATION = 2.24;
const GROUND = 329;
const PALM_CONTACT = .211;
const PALM_X = 174;
const STRIKE = 1.13;
const gates = [
  { x: 315, y: 327, height: 191, start: .34, exit: 1.76, texture: 'gate-indigo', light: '#83b8ff', seed: 18 },
  { x: 491, y: 328, height: 217, start: .46, exit: 1.65, texture: 'gate-jade', light: '#92f5b4', seed: 42 },
  { x: 679, y: 330, height: 246, start: .58, exit: 1.54, texture: 'gate-vermilion', light: '#ff7860', seed: 73 },
];
const FORMATION = .638;
const STRIKE_V2 = 1.12;
const formationGates = [
  { x: 359, y: 325, height: 151, start: .346, breakAt: .284, exit: 1.76,
    rise: .158, texture: 'gate-indigo', light: '#83b8ff', seed: 152, trim: 'iron' },
  { x: 472, y: 328, height: 177, start: .384, breakAt: .315, exit: 1.65,
    rise: .162, texture: 'gate-jade', light: '#92f5b4', seed: 206, trim: 'jade' },
  { x: 603, y: 331, height: 207, start: .416, breakAt: .352, exit: 1.54,
    rise: .179, texture: 'gate-vermilion', light: '#ff7860', seed: 273, trim: 'red', front: true },
];
const mobileGates = [
  { x: 307, y: 335, height: 168, widthScale: 1.15, start: .299, breakAt: .272, exit: 1.53,
    rise: .128, texture: 'gate-indigo', light: '#83b8ff', seed: 315, trim: 'iron', mobile: true },
  { x: 386, y: 329, height: 180, widthScale: 1.12, start: .403, breakAt: .374, exit: 1.65,
    rise: .135, texture: 'gate-jade', light: '#92f5b4', seed: 428, trim: 'jade', mobile: true },
  { x: 471, y: 323, height: 192, widthScale: 1.11, start: .509, breakAt: .48, exit: 1.76,
    rise: .139, texture: 'gate-vermilion', light: '#ff7860', seed: 512, trim: 'red', front: true, mobile: true },
];
const flatCenters = [307, 393, 481];
const flatGates = mobileGates.map((gate, index) => ({
  ...gate, x: flatCenters[index], y: GROUND, height: 178, widthScale: 1.06, flat: true,
}));
const illustratedDoors = [
  { x: 297, texture: 'gate-v5-blue' },
  { x: 389, texture: 'gate-v5-green' },
  { x: 481, texture: 'gate-v5-red' },
];
const illustratedGates = flatGates.map((gate, index) => ({
  ...gate, ...illustratedDoors[index], artwork: true, width: 144,
}));
const angledGates = illustratedGates.map(gate => ({
  ...gate, texture: gate.texture.replace('-v5-', '-v6-'),
}));
const redrawnGates = angledGates.map((gate, index) => ({
  ...gate, texture: gate.texture.replace('-v6-', '-v7-'),
  height: [171, 186, 181][index], width: [128, 136, 134][index],
}));
const clamp = (n, low = 0, high = 1) => Math.max(low, Math.min(high, n));
const easeOut = n => 1 - (1 - clamp(n)) ** 2;
const easeIn = n => clamp(n) ** 2;
const fade = (t, from, to) => 1 - clamp((t - from) / (to - from));

function randomFrom(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 2 ** 32;
  };
}

for (const gate of [
  ...gates, ...formationGates, ...mobileGates, ...flatGates,
  ...illustratedGates, ...angledGates, ...redrawnGates,
]) {
  const random = randomFrom(gate.seed);
  const heavy = Boolean(gate.trim);
  gate.rocks = Array.from({ length: 23 }, (_, i) => {
    const side = i % 2 ? 1 : -1;
    return { side, x: side * (18 + random() * 43), vx: side * (30 + random() * (heavy ? 128 : 155)),
      vy: (heavy ? 96 : 68) + random() * (heavy ? 220 : 168),
      size: 1.4 + random() ** 2 * (heavy ? 12.7 : 7.5),
      lag: random() * .055, turn: (random() - .5) * 14 };
  });
  gate.puffs = Array.from({ length: 10 }, (_, i) => {
    const side = i % 2 ? 1 : -1;
    return { side, x: side * (21 + random() * 51), vx: side * (31 + random() * 68),
      vy: 15 + random() * 50, size: 23 + random() * 34, lag: random() * .085,
      tone: i < 5 ? 0 : 1, frame: i % 3, turn: (random() - .5) * 2 };
  });
  gate.cracks = [-1, 1].map(side => Array.from({ length: 3 }, (_, i) => {
    const y = 3 + i * 5;
    return [[0, 2], [side * 19, y], [side * (33 + random() * 12), y - 4],
      [side * (47 + random() * 10), y + 1], [side * (66 + random() * 13), y + (random() - .4) * 13]];
  })).flat();
  if (gate.mobile) {
    gate.roots = Array.from({ length: 10 }, (_, i) => ({
      x: -70 + i * 15 + (random() - .5) * 9, y: 3 + random() * 5,
      height: 8 + random() * 19, width: 4 + random() * 8, slant: (random() - .48) * 21,
    }));
  }
}

function path(ctx, points) {
  ctx.beginPath();
  ctx.moveTo(...points[0]);
  for (const point of points.slice(1)) ctx.lineTo(...point);
}

function polygon(ctx, points, color) {
  path(ctx, points);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

function ellipse(ctx, x, y, rx, ry, color) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
}

function spriteCell(ctx, img, index, width, height, pivot, x, y, scale) {
  const columns = Math.floor(img.width / width);
  ctx.drawImage(img, index % columns * width, Math.floor(index / columns) * height,
    width, height, x - pivot[0] * scale, y - pivot[1] * scale, width * scale, height * scale);
}

function background(ctx, images, stage) {
  if (stage === 'light') {
    ctx.fillStyle = '#bebbb9';
    ctx.fillRect(0, 0, WIDTH, HEIGHT);
    ctx.fillStyle = '#aaa4a1';
    ctx.fillRect(0, GROUND, WIDTH, HEIGHT - GROUND);
    return;
  }
  const art = images.stage;
  const imageWidth = 960;
  const imageHeight = imageWidth * art.height / art.width;
  ctx.drawImage(art, 0, GROUND - imageHeight * .835, imageWidth, imageHeight);
  ctx.fillStyle = 'rgba(12,15,24,.42)';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  const edge = ctx.createLinearGradient(0, 0, 0, HEIGHT);
  edge.addColorStop(0, 'rgba(10,13,23,.38)');
  edge.addColorStop(.8, 'rgba(10,13,23,0)');
  edge.addColorStop(1, 'rgba(10,13,23,.52)');
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
}

const castCels = [
  [.100, 1], [.147, 2], [.180, 3], [PALM_CONTACT, 4],
  [.369, 3], [.405, 5], [.452, 6], [.505, 0],
];

function actor(ctx, images, t, useCast = false) {
  ellipse(ctx, 125, GROUND + 1, 49, 6, '#15151c9c');
  if (useCast) {
    const index = castCels.findLast(([start]) => t >= start)?.[1] ?? 0;
    spriteCell(ctx, images['actor-v7-cast'], index, 172, 146, [0, 139], 44, GROUND, 1);
    return;
  }
  const pose = t < .16 || t > 1.81 ? 'idle' : t < .34 ? 'seal' : t < .56 ? 'ward' : 'guard';
  ctx.drawImage(images['actor-' + pose], 47, GROUND - 131, 149, 137);
}

function seal(ctx, gate, t) {
  const age = t - (gate.start - .14);
  if (age < 0 || age > .31) return;
  const strength = Math.sin(Math.PI * clamp(age / .31));
  ctx.save();
  ctx.translate(gate.x, gate.y);
  ctx.scale(1, .155);
  ctx.globalAlpha = strength * .72;
  ctx.strokeStyle = gate.light;
  ctx.lineWidth = 2.6;
  for (const radius of [49, 60]) {
    ctx.beginPath();
    ctx.arc(0, 0, radius * (.86 + .14 * easeOut(age / .14)), 0, Math.PI * 2);
    ctx.stroke();
  }
  for (let i = 0; i < 12; i++) {
    const angle = i * Math.PI / 6 + age * 1.25;
    path(ctx, [[Math.cos(angle) * 52, Math.sin(angle) * 52],
      [Math.cos(angle) * 57, Math.sin(angle) * 57]]);
    ctx.stroke();
  }
  ctx.restore();
}

function groundBreak(ctx, gate, t) {
  const age = t - (gate.breakAt ?? gate.start);
  if (age < 0) return;
  const opacity = fade(t, gate.exit + .03, gate.exit + .35);
  const growth = easeOut(age / .12);
  ctx.save();
  ctx.translate(gate.x, gate.y);
  ctx.scale(growth, growth);
  ctx.globalAlpha = opacity;
  ellipse(ctx, 1, 3, 73, 7, '#241714a0');
  for (const crack of gate.cracks) {
    path(ctx, crack);
    ctx.lineWidth = 2.2;
    ctx.strokeStyle = '#211a1bea';
    ctx.stroke();
    if (age < .22 && !gate.trim) {
      ctx.strokeStyle = gate.light + '88';
      ctx.lineWidth = .85;
      ctx.stroke();
    }
  }
  ctx.restore();
}

function gatePose(gate, t, block) {
  const age = t - gate.start;
  if (age < 0 || t >= gate.exit + .26) return null;
  if (gate.trim) {
    const rise = 1 - (1 - clamp(age / gate.rise)) ** 2.5;
    const over = age > gate.rise ? 6.2 * Math.sin((age - gate.rise) * 35) * Math.exp(-(age - gate.rise) * 18) : 0;
    const lock = Math.max(0, t - FORMATION);
    const mass = !gate.mobile && t >= FORMATION ? 3.9 * Math.sin(lock * 55) * Math.exp(-lock * 25) : 0;
    const hit = t - STRIKE_V2;
    const recoil = block && gate.front && hit >= 0 && hit < .22
      ? -17 * easeOut(hit / .035) * fade(hit, .036, .22) : 0;
    const stretch = gate.flat ? 1 + over / gate.height : 1;
    return { age, recoil, stretch, y: gate.y - gate.height * rise - over + mass +
      gate.height * easeIn((t - gate.exit) / .26) };
  }
  const rise = easeOut(age / .174);
  const settle = Math.max(0, age - .162);
  const recoilAge = t - STRIKE;
  const isFront = gate === gates.at(-1);
  const recoil = block && isFront && recoilAge >= 0 && recoilAge < .19
    ? -15 * Math.sin(Math.PI * recoilAge / .19) * (1 - recoilAge / .23) : 0;
  return { age, recoil, y: gate.y - gate.height * rise +
      4.8 * Math.sin(settle * 37) * Math.exp(-settle * 20) +
      gate.height * easeIn((t - gate.exit) / .26) };
}

function sideTrim(ctx, gate, width, age, t) {
  const h = gate.height;
  if (gate.mobile && gate.trim === 'iron') {
    polygon(ctx, [[-width * .39, h * .75], [-width * .53, h * .53], [-width * .665, h * .25],
      [-width * .6, h * .275], [-width * .475, h * .41], [-width * .345, h * .41]], '#25324c');
    polygon(ctx, [[-width * .655, h * .255], [-width * .513, h * .52],
      [-width * .438, h * .59], [-width * .476, h * .425]], '#43658c');
  }
  if (gate.mobile && gate.trim === 'jade') {
    const tip = gate.flat ? .035 : -.10;
    polygon(ctx, [[width * .12, h * .41], [width * .19, h * .12], [width * .33, h * tip],
      [width * .385, h * .17], [width * .51, h * (tip + .082)], [width * .453, h * .38]], '#203c35');
    polygon(ctx, [[width * .194, h * .14], [width * .331, h * (tip + .007)],
      [width * .323, h * .18], [width * .25, h * .3]], '#427761');
  }
  if (gate.trim === 'red') {
    for (const side of [-1, 1]) {
      ctx.save();
      ctx.scale(side, 1);
      polygon(ctx, [[width * .31, h * .29], [width * .49, h * .19], [width * .59, h * .143],
        [width * .552, h * .415], [width * .592, h * .438], [width * .528, h * .69],
        [width * .548, h * .926], [width * .37, h * .977]], '#291a20');
      polygon(ctx, [[width * .44, h * .32], [width * .575, h * .173],
        [width * .535, h * .409], [width * .476, h * .583]], '#7d3731');
      polygon(ctx, [[width * .453, h * .659], [width * .537, h * .488],
        [width * .496, h * .778], [width * .527, h * .902], [width * .43, h * .92]], '#552826');
      ctx.restore();
    }
  } else if (gate.trim === 'jade') {
    polygon(ctx, [[width * .22, h * .62], [width * .34, h * .17], [width * .461, h * .013],
      [width * .442, h * .405], [width * .526, h * .325], [width * .461, h * .74], [width * .36, h * .92]],
    '#193e34');
    polygon(ctx, [[width * .345, h * .19], [width * .453, h * .025], [width * .423, h * .417],
      [width * .32, h * .63]], '#396656');
  } else {
    const swing = 9 * Math.sin(age * 16) * Math.exp(-age * 3.5);
    const lock = Math.max(0, t - FORMATION);
    const jolt = !gate.mobile && t > FORMATION ? 12 * Math.sin(lock * 23) * Math.exp(-lock * 7) : 0;
    for (const side of [-1, 1]) {
      const x = side * width * .42;
      const dx = (swing + jolt + 7) * side;
      path(ctx, [[x, h * .19], [x + dx * .7, h * .37], [x + dx, h * .52]]);
      ctx.lineWidth = 2.4;
      ctx.strokeStyle = '#191e2c';
      ctx.stroke();
      polygon(ctx, [[x + dx - 2, h * .49], [x + dx + 3, h * .51], [x + dx + 3, h * .58],
        [x + dx - 3, h * .58]], '#526075');
    }
  }
}

function drawGate(ctx, images, gate, t, block) {
  const pose = gatePose(gate, t, block);
  if (!pose) return;
  const img = images[gate.texture];
  const width = gate.width ?? gate.height * img.width / img.height * (gate.widthScale ?? 1);
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, 0, WIDTH, gate.y + .6);
  ctx.clip();
  ctx.translate(gate.x + pose.recoil, pose.y);
  if (gate.flat) ctx.scale(1, pose.stretch);
  if (gate.trim && !gate.artwork) sideTrim(ctx, gate, width, pose.age, t);
  ctx.drawImage(img, -width / 2, 0, width, gate.height);
  if (!gate.artwork && pose.age > .13 && t < gate.exit) {
    const glow = Math.max(0, Math.sin(Math.PI * clamp((pose.age - .13) / .38)));
    ctx.save();
    ctx.globalAlpha = glow * .41;
    ctx.shadowColor = gate.light;
    ctx.shadowBlur = 12;
    polygon(ctx, [[-.133 * width, .575 * gate.height], [-.053 * width, .596 * gate.height],
      [-.095 * width, .596 * gate.height]], gate.light);
    polygon(ctx, [[.075 * width, .575 * gate.height], [.012 * width, .596 * gate.height],
      [.044 * width, .595 * gate.height]], gate.light);
    ctx.restore();
  }
  ctx.restore();
}

function dust(ctx, images, gate, age, back, exit = false) {
  if (exit) age *= 1.52;
  if (age < 0 || age > .72) return;
  const scale = exit ? .60 : 1;
  if (!back && !exit && age < .55) {
    const frame = Math.min(18, Math.floor(age / .55 * 19));
    ctx.save();
    ctx.globalAlpha = fade(age, .28, .55) * .81;
    spriteCell(ctx, images['project-dust'], frame, 176, 80, [88, 60], gate.x, gate.y + 4, 1.22);
    ctx.restore();
  }
  for (const particle of gate.puffs) {
    if ((particle.tone === 0) !== back) continue;
    const a = age - particle.lag;
    if (a < 0 || a > .63) continue;
    const rise = easeOut(a / .21);
    const x = gate.x + (particle.x + particle.vx * a) * scale;
    const y = gate.y + 3 - (6 + rise * particle.vy) * scale;
    const size = particle.size * scale * (.72 + 1.27 * easeOut(a / .48));
    const alpha = easeOut(a / .055) * fade(a, .08, .63);
    const img = images['puff-' + particle.tone + '-' + particle.frame];
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(particle.turn * (.55 + a));
    ctx.globalAlpha = alpha * (back ? .57 : .63);
    ctx.drawImage(img, -size / 2, -size * .34, size, size * .68);
    ctx.restore();
  }
}

function fragments(ctx, gate, t, exit = false) {
  const age = exit ? (t - gate.exit - .06) * 1.68 : t - (gate.breakAt ?? gate.start);
  if (age < 0 || age > .7) return;
  for (const rock of gate.rocks) {
    const a = age - rock.lag;
    const gravity = gate.mobile ? 745 : gate.trim ? 450 : 342;
    const height = rock.vy * a - gravity * a * a;
    if (a < 0 || height < -1 || (exit && rock.size > 6)) continue;
    const scale = exit ? .64 : 1;
    const x = gate.x + (rock.x + a * rock.vx) * scale;
    const y = gate.y - height * scale;
    const size = rock.size * scale;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(a * rock.turn + rock.size);
    ctx.globalAlpha = fade(a, .28, .7);
    polygon(ctx, [[-size, .22 * size], [-.22 * size, -size], [.63 * size, -.53 * size],
      [size, .22 * size], [.23 * size, .83 * size]], '#392c30');
    polygon(ctx, [[-size, .22 * size], [-.22 * size, -size], [.63 * size, -.53 * size],
      [.08 * size, .2 * size]], '#967057');
    ctx.restore();
  }
}

function earthBurst(ctx, gate, t) {
  const age = t - gate.breakAt;
  if (age < 0 || age > .32) return;
  const flight = easeOut(age / .24);
  const peak = easeOut(age / .082) * fade(age, .105, .32) * (gate.mobile ? .63 : 1);
  ctx.save();
  ctx.translate(gate.x, gate.y);
  ctx.globalAlpha = fade(age, .14, .32);
  for (const side of [-1, 1]) {
    ctx.save();
    ctx.scale(side, 1);
    polygon(ctx, [[13, 2], [15 + flight * 24, -7], [25 + flight * 35, -64 * peak],
      [34 + flight * 41, -24 * peak], [41 + flight * 53, -42 * peak],
      [49 + flight * 69, -8 * peak], [63 + flight * 71, 5], [29, 7]], '#715247');
    polygon(ctx, [[20, 0], [25 + flight * 35, -64 * peak], [34 + flight * 41, -24 * peak],
      [46 + flight * 63, -14 * peak], [56 + flight * 63, -3]], '#a17b60');
    ctx.restore();
  }
  ctx.restore();
}

function rootedStone(ctx, gate, t) {
  const age = t - gate.breakAt;
  if (age < 0 || t >= gate.exit + .39) return;
  const body = easeOut(age / .12);
  ctx.save();
  ctx.translate(gate.x, gate.y);
  ctx.globalAlpha = body * fade(t, gate.exit + .08, gate.exit + .39);
  for (const rock of gate.roots) {
    const x = rock.x * (.78 + .22 * body);
    const y = rock.y;
    const h = rock.height * body;
    const w = rock.width;
    polygon(ctx, [[x - w, y], [x - w * .72, y - h * .45], [x + rock.slant, y - h],
      [x + w * .51, y - h * .54], [x + w * 1.22, y]], '#594338');
    polygon(ctx, [[x - w, y], [x - w * .72, y - h * .45], [x + rock.slant, y - h],
      [x + w * .12, y - h * .20]], '#a78563');
  }
  ctx.restore();
}

function groundSignal(ctx, t, fromPalm) {
  const age = t - (fromPalm ? PALM_CONTACT : .219);
  if (age < 0 || age > .25) return;
  const origin = fromPalm ? PALM_X : 145;
  const reach = origin + 4 + (328 - origin) * easeOut(age / .13);
  ctx.save();
  ctx.globalAlpha = fade(age, .065, .25) * .81;
  path(ctx, [[origin, 331], [origin + (reach - origin) * .23, 328],
    [origin + (reach - origin) * .49, 332], [origin + (reach - origin) * .76, 325], [reach, 328]]);
  ctx.strokeStyle = '#5c4239';
  ctx.lineWidth = 2.4;
  ctx.stroke();
  ellipse(ctx, reach, 328, 10 * fade(age, .06, .25) + 1, 1.4, '#ca9b7055');
  ctx.restore();
}

function palmDust(ctx, images, t) {
  const age = t - PALM_CONTACT;
  if (age < 0 || age > .19) return;
  const travel = easeOut(age / .19);
  const sprite = images['puff-0-1'];
  const size = 14 + 23 * travel;
  ctx.save();
  ctx.globalAlpha = .58 * Math.sin(Math.PI * (travel ** .58));
  ctx.drawImage(sprite, PALM_X + 1 + 13 * travel, GROUND - size * .78 - 11 * travel, size, size);
  ctx.restore();
}

function formationPulse(ctx, images, t) {
  const age = t - FORMATION;
  if (age < 0 || age > .39) return;
  const travel = easeOut(age / .39);
  const edge = 119 + travel * 145;
  const grit = 4 + travel * 12;
  ctx.save();
  ctx.translate(486, GROUND + 5);
  ctx.globalAlpha = fade(age, .031, .28) * .62;
  polygon(ctx, [[-edge, 5], [-edge + 24, -2], [-edge + 42, -grit],
    [-edge + 79, -grit * .42], [-76, -8], [-20, -5], [34, -11], [90, -4],
    [edge - 72, -grit * .50], [edge - 30, -grit * .32], [edge, 4],
    [edge - 40, 8], [-edge + 57, 9]], '#aa8065');
  ctx.restore();
  for (const gate of formationGates) {
    dust(ctx, images, gate, age * 1.56 + .028, false, true);
    ctx.save();
    ctx.globalAlpha = fade(age, .026, .25) * .56;
    ctx.strokeStyle = '#d4ac88';
    ctx.lineWidth = 1.7 - travel * .9;
    ctx.beginPath();
    ctx.ellipse(gate.x, gate.y + 1, 45 + travel * 102, 2 + travel * 8, 0, .15, 2.99);
    ctx.stroke();
    ctx.restore();
  }
}

function groundWave(ctx, gate, t) {
  const age = t - gate.start;
  if (age < 0 || age > .235) return;
  const grow = easeOut(age / .235);
  ctx.save();
  ctx.translate(gate.x, gate.y + 1);
  ctx.globalAlpha = (1 - grow) * .83;
  ctx.strokeStyle = '#e7bc99';
  ctx.lineWidth = 2.6 - grow * 1.6;
  ctx.beginPath();
  ctx.ellipse(0, 0, 29 + grow * 89, 1 + grow * 12, 0, .2, Math.PI * 1.86);
  ctx.stroke();
  for (const side of [-1, 1]) {
    const drift = (17 + grow * 71) * side;
    polygon(ctx, [[drift, 1], [drift + side * 31, 3], [drift + side * 15, -4],
      [drift + side * 26, -23 * (1 - grow)], [drift + side * 1, -8]], '#b88f735e');
  }
  ctx.restore();
}

const sparkRandom = randomFrom(219);
const sparks = Array.from({ length: 29 }, (_, i) => ({
  angle: -.99 + i / 28 * 1.98 + (sparkRandom() - .5) * .16,
  speed: 88 + sparkRandom() * 335,
  length: 3 + sparkRandom() ** 2 * 19,
  drag: 2 + sparkRandom() * 4,
}));

function projectile(ctx, t) {
  const front = gates.at(-1);
  const pose = gatePose(front, t, true);
  const x = front.x + front.height * .26 + (pose?.recoil ?? 0);
  const y = 194;
  const age = t - STRIKE;
  if (t < .89 || age > .46) return;
  ctx.save();
  if (age < 0) {
    const head = x + (-age / .24) * 246;
    const trail = ctx.createLinearGradient(head, y, head + 136, y);
    trail.addColorStop(0, '#ffe1a2');
    trail.addColorStop(.29, '#fa765a');
    trail.addColorStop(1, '#db355000');
    polygon(ctx, [[head, y - 17], [head + 140, y - 4], [head + 97, y + 4], [head, y + 17]], trail);
    ctx.shadowColor = '#fd604c';
    ctx.shadowBlur = 21;
    ellipse(ctx, head + 7, y, 23, 18, '#fb7259');
    ellipse(ctx, head + 2, y - 1, 14, 12, '#fff1bf');
  } else {
    const glow = ctx.createRadialGradient(x, y, 1, x, y, 35 + age * 124);
    glow.addColorStop(0, '#fff4c6e0');
    glow.addColorStop(.33, '#ff9d58a0');
    glow.addColorStop(1, '#ff542d00');
    ctx.globalAlpha = fade(age, 0, .28);
    ellipse(ctx, x, y, 36 + age * 124, 36 + age * 124, glow);
    const flash = fade(age, .016, .105);
    ctx.globalAlpha = flash;
    polygon(ctx, [[x - 12, y - 9], [x + 6, y - 17], [x + 19, y - 39], [x + 17, y - 12],
      [x + 43, y - 26], [x + 31, y - 7], [x + 52, y + 4], [x + 21, y + 8],
      [x + 31, y + 31], [x + 8, y + 14], [x - 6, y + 21]], '#fff0c0');
    ctx.globalAlpha = fade(age, .05, .19) * .86;
    polygon(ctx, [[x - 8, y - 6], [x + 11, y - 17], [x + 8, y - 1],
      [x + 17, y + 7], [x + 4, y + 17], [x - 9, y + 7]], '#ffb377');
    ctx.globalAlpha = fade(age, 0, .31);
    ctx.strokeStyle = '#ffdf9d';
    ctx.lineWidth = 2.2 * (1 - age);
    ctx.beginPath();
    ctx.ellipse(x + 8, y, 8 + age * 157, 14 + age * 209, 0, -1.6, 1.6);
    ctx.stroke();
    for (const spark of sparks) {
      const travel = spark.speed * (1 - Math.exp(-age * spark.drag)) / spark.drag;
      const sx = x + travel * Math.cos(spark.angle);
      const sy = y + travel * Math.sin(spark.angle) + age * age * 88;
      const size = spark.length * fade(age, .05, .47);
      ctx.globalAlpha = fade(age, .045, .46) * .85;
      polygon(ctx, [[sx, sy], [sx + size, sy + size * Math.tan(spark.angle) * .58],
        [sx + 2, sy + 2.4]], '#ffae70');
    }
  }
  ctx.restore();
}

function formationImpact(ctx, images, t, group) {
  const gate = group.at(-1);
  const age = t - STRIKE_V2;
  if (age < -.17 || age > .44) return;
  const y = gate.y - gate.height * .59;
  const edge = gate.width ? gate.width * .45 : gate.height * .318 * (gate.widthScale ?? 1);
  const x = gate.x + edge + (gatePose(gate, t, true)?.recoil ?? 0);
  ctx.save();
  if (age < 0) {
    const head = x - age * 1670;
    const tint = ctx.createLinearGradient(head, y, head + 234, y);
    tint.addColorStop(0, '#fff7c7');
    tint.addColorStop(.22, '#fa6855');
    tint.addColorStop(.58, '#d9464ca3');
    tint.addColorStop(1, '#d9464c00');
    polygon(ctx, [[head, y], [head + 27, y - 11], [head + 165, y - 16], [head + 230, y - 3],
      [head + 230, y + 6], [head + 151, y + 14], [head + 29, y + 12]], tint);
    ellipse(ctx, head + 16, y, 18, 10, '#ffaf78');
    ellipse(ctx, head + 10, y, 10, 6, '#fff5c6');
  } else {
    const swell = (age - .126) / .054;
    const flare = Math.exp(-age * 14) + .57 * Math.exp(-(swell ** 2));
    const radius = 20 + 74 * easeOut(age / .34);
    const halo = ctx.createRadialGradient(x, y, 0, x, y, radius);
    halo.addColorStop(0, '#fff9d9');
    halo.addColorStop(.22, '#ffb36bc0');
    halo.addColorStop(.56, '#ed5f4b55');
    halo.addColorStop(1, '#e03a3600');
    ctx.globalAlpha = Math.min(1, flare);
    ellipse(ctx, x, y, radius, radius, halo);
    ctx.globalAlpha = clamp(flare * 1.1);
    ellipse(ctx, x + 3, y, 6 + 11 * flare, 5 + 18 * flare, '#fff5c2');
    polygon(ctx, [[x, y], [x + 13, y - 6], [x + 71, y - 33], [x + 31, y + 1],
      [x + 53, y + 18], [x + 12, y + 6]], '#ffb16c');
    for (const [index, delay] of [0, .094].entries()) {
      const ringAge = age - delay;
      if (ringAge < 0 || ringAge > .29) continue;
      const ring = easeOut(ringAge / .29);
      ctx.globalAlpha = (1 - ring) * (index ? .53 : .85);
      ctx.strokeStyle = '#ffd3a7';
      ctx.lineWidth = 2.25 - ring;
      ctx.beginPath();
      ctx.ellipse(x + 6 + ring * 21, y, 4 + ring * 31, 16 + ring * 70, 0, -1.38, 1.24);
      ctx.stroke();
    }
    for (const spark of sparks) {
      const travel = spark.speed * (1 - Math.exp(-age * spark.drag)) / spark.drag;
      const sx = x + travel * Math.cos(spark.angle) * 1.32;
      const sy = y + travel * Math.sin(spark.angle) * 1.35 + age * age * 88;
      const length = spark.length * (1.04 - age * 1.5);
      ctx.globalAlpha = fade(age, .045, .39) * .91;
      polygon(ctx, [[sx, sy], [sx + length, sy + length * Math.tan(spark.angle) * .6],
        [sx + 2, sy + 2.3]], '#ffba82');
    }
    dust(ctx, images, gate, age * 1.2, false, true);
  }
  ctx.restore();
}

function frame(ctx, images, t, settings = {}) {
  const { stage = 'theatre', scene = 'new', block = false, mirror = false, actorVisible = true,
    variant = 'v1' } = settings;
  const farGateOnTop = variant === 'v8';
  const redrawn = farGateOnTop || variant === 'v7';
  const angled = redrawn || variant === 'v6';
  const illustrated = angled || variant === 'v5';
  const flat = illustrated || variant === 'v4';
  const mobile = flat || variant === 'v3';
  const layered = mobile || variant === 'v2';
  const formation = redrawn ? redrawnGates : angled ? angledGates : illustrated ? illustratedGates : flat ? flatGates
    : mobile ? mobileGates : layered ? formationGates : gates;
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  if (stage !== 'alpha') background(ctx, images, stage);
  ctx.save();
  if (mirror) {
    ctx.translate(WIDTH, 0);
    ctx.scale(-1, 1);
  }
  if (scene === 'ward') {
    if (actorVisible) actor(ctx, images, t);
    if (t < .4) {
      spriteCell(ctx, images['project-ward'], Math.min(33, Math.floor(t / .4 * 34)),
        148, 104, [40, 88], 154, GROUND - 69, 1.02);
    }
    ctx.restore();
    return;
  }
  if (layered) groundSignal(ctx, t, redrawn);
  if (redrawn) palmDust(ctx, images, t);
  for (const gate of formation) {
    if (!layered) seal(ctx, gate, t);
    groundBreak(ctx, gate, t);
    dust(ctx, images, gate, t - (gate.breakAt ?? gate.start), true);
    dust(ctx, images, gate, t - gate.exit, true, true);
  }
  if (actorVisible) actor(ctx, images, t, redrawn);
  if (mobile) {
    // Formation is stored from the caster outward. Paint the far gate last in V8.
    const drawOrder = farGateOnTop || (flat && !angled) ? formation : formation.toReversed();
    for (const gate of drawOrder) {
      drawGate(ctx, images, gate, t, block);
      rootedStone(ctx, gate, t);
    }
  } else {
    for (const gate of formation) drawGate(ctx, images, gate, t, block);
  }
  for (const gate of formation) {
    if (layered) earthBurst(ctx, gate, t);
    else groundWave(ctx, gate, t);
    dust(ctx, images, gate, t - (gate.breakAt ?? gate.start), false);
    dust(ctx, images, gate, t - gate.exit, false, true);
    fragments(ctx, gate, t);
    fragments(ctx, gate, t, true);
  }
  if (layered) {
    if (!mobile) formationPulse(ctx, images, t);
    if (block) formationImpact(ctx, images, t, formation);
  } else if (block) {
    dust(ctx, images, gates.at(-1), t - STRIKE + .02, false, true);
    projectile(ctx, t);
  }
  ctx.restore();
}

globalThis.rashomon = { frame, FPS, DURATION, WIDTH, HEIGHT };
