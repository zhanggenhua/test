# 龟波气功 pixelfx 风格试验

三版共用同一套播放和变距逻辑。base 是上游蓝色基线，tint 仅改冰青色阶，sharp 沿用冰青色阶，重绘束身截面、外缘、流动碎片和掌心爆点。角色只用于网页预览。

每种风格有四张透明图集，JSON 记录像素枢轴、显示比例、帧矩形和时长。`charge` 跟随双掌，`emitter` 放在出手点，`body` 从出手点开始按实际距离裁切，`impact` 只在实际命中点显示。束身的横向像素比例固定。网页参考射程是 100–440 px。`timeline.json` 里的事件以此预览使用的角色动作计时。收束时缩窄束身并淡出，未命中端用最多 34 px 的透明收口，命中点留 4 px 过渡。

参数和改动画法在 `source/`。重渲染可在 Patch pixelfx 提交 `5294518` 的临时环境中，把 `source/` 内 4 个效果目录放入 `src/fx/`，运行 `node tools/check.mjs beam-base beam-tint beam-sharp`，再运行 `node tools/render.mjs beam-base beam-tint beam-sharp --no-actor --sheet`。图集中的光晕由 pixelfx 合成至透明图像。

基于 [Patch pixelfx](https://github.com/patch-gg/pixelfx/tree/5294518) 和 Hugo Duprez 的 [Sprite Fusion Energy](https://www.spritefusion.com/pixel-art-vfx/energy)。保留随包的 LICENSE、NOTICE.md 和源文件署名。
