// Adapted from Patch pixelfx arcane-beam (5294518) and Sprite Fusion's energy effect.
// MIT, Copyright (c) 2026 Hugo Duprez. See the accompanying notices.
import { fit, cycle, fract, TAU, WHITE } from "../../core/index.js";

const PERIOD = 1.2;
const X = 15, Y = -24, SPAN = 168;

export function body(p, t, o) {
  const colors = fit(o.palette, 8);
  const phase = t / PERIOD;
  const wave = phase * TAU;
  const shade = [WHITE, colors[6], colors[5], colors[4], colors[3], colors[2]];
  for (let d = 0; d <= SPAN; d += .5) {
    const x = X + d;
    const throat = Math.min(1, (d + 5) / 19);
    const swell = Math.sin(d * .145 - wave * 3);
    const current = Math.sin(d * .24 - wave * 6);
    const center = Y + .85 * Math.sin(d * .065 - wave * 2) * throat;
    const upper = (6.7 + .92 * swell + .42 * current) * throat;
    const lower = (5.35 + .61 * Math.sin(d * .13 - wave * 3 + 1.7)) * throat;
    const pulse = fract(d / 47 - phase * 4);
    const surge = pulse < .12 ? 1 : 0;
    for (let y = Math.floor(center - upper); y <= center + lower; y++) {
      const q = Math.abs(y - center) / (y < center ? upper : lower);
      if (q > 1) continue;
      const step = q < .28 ? 0 : q < .46 ? 1 : q < .65 ? 2 : q < .79 ? 3 : q < .92 ? 4 : 5;
      p.px(x, y, shade[Math.max(0, step - (step < 5 ? surge : 0))]);
    }
    for (let s = 0; s < 3; s++) {
      const turn = d * .155 - wave * 4 + s * TAU / 3;
      const off = Math.sin(turn);
      if (Math.cos(turn) > .4 && d > 8) {
        p.dot(x, center + off * (off < 0 ? upper * .85 : lower * .86), s ? colors[6] : WHITE);
      }
    }
    if (d % 4 === 0) p.glow(x, center, upper * 1.52 + 2, colors[4], .082);
  }
  for (let i = 0; i < 6; i++) {
    const age = fract(phase * 2 + i / 6);
    const x = X + 18 + age * (SPAN - 25);
    const side = i % 2 ? 1 : -1;
    const rise = side * (6 + i % 3);
    const len = 11 + i % 3 * 5;
    const strength = Math.sin(Math.PI * age);
    p.tri(x - len, Y + rise * .6, x - len * .37, Y + rise,
      x + 2, Y + rise * 1.03, colors[4], strength * .83);
    p.line(x - len * .47, Y + rise * .94, x + .4, Y + rise * 1.02, colors[6], strength * .66);
  }
  cycle(t, PERIOD, 15, o.seed * 5, r => r.range(.28, .55), (age, life, r) => {
    const q = age / life, side = r.sign();
    const x = X + r.range(17, SPAN - 23) + q * 28;
    const y = Y + side * (r.range(7, 11) + q * 3);
    const len = r.range(3, 12) * (1 - q);
    const alpha = .78 * Math.sin(Math.PI * q);
    p.tri(x - len, y + side * .8, x, y - side * .6, x + 2, y - side * 1.0,
      colors[r.chance(.4) ? 6 : 4], alpha);
  });
}

export function emitter(p, t, o) {
  const c = fit(o.palette, 8);
  const phase = t / PERIOD * TAU;
  const r = 4.4 + .65 * Math.sin(phase * 10);
  for (let i = 0; i < 7; i++) {
    const a = i * TAU / 7 + phase;
    const dx = Math.cos(a), dy = Math.sin(a);
    const length = 10 + (i % 3) * 2.5 + Math.sin(phase * 5 + i) * 2;
    p.tri(X + dy * 2.5, Y - dx * 2.5, X - dy * 2.5, Y + dx * 2.5,
      X + dx * length, Y + dy * length, c[3]);
    p.line(X, Y, X + dx * length * .79, Y + dy * length * .79, c[6], .88);
  }
  p.circle(X, Y, r + 1.6, c[2]);
  p.circle(X, Y, r, c[5]);
  p.circle(X - .5, Y - .5, r * .64, WHITE);
  p.glow(X, Y, 20, c[5], .43);
}

