// The beam (banded across, pulses running down it, sine strands that brighten in front, a source flare with
// spinning rays, an end flare spraying rays and sparks) is adapted from Sprite Fusion's open-source energy beam
// (https://www.spritefusion.com/pixel-art-vfx/energy), MIT License, Copyright (c) 2026 Hugo Duprez.
// Derived from Patch pixelfx 5294518 (MIT); keep this attribution.
import { PAL, fit, cycle, fly, flyV, loopNoise, fract, ease, sparkle, TAU, WHITE, READY } from "../../core/index.js";
import { bayer, mote } from "../arcane/_lib.js";

const D = 1.2, HX = 15, HY = -24, L = 168, W = 6;

export const meta = {
  name: "Arcane beam upstream impact", desc: "An isolated layer from the upstream Arcane beam.",
  tags: ["arcane", "beam"], size: [264, 100], origin: [26, 84],
  duration: D, loop: true, fps: 30, bg: "dark",
  options: { palette: ["#101734","#173665","#245bb2","#2e8cf0","#55c1ff","#98e9ff","#ddf9ff","#ffffff"], seed: 10 },
};

export function draw(p, t, o) {
  const C = fit(o.palette, 8), ph = t / D, S = o.seed, EX = HX + L;
  // the end: a hot flare spraying rays, rings shocking out, sparks thrown back and falling
  const ir = 5 + Math.sin(ph * TAU * 12) * 0.8;
  for (let i = 0; i < 7; i++) {
    const a = Math.PI + (i - 3) * 0.36, l = 8 + 8 * Math.abs(loopNoise(ph, 4, S * 7 + i));
    p.line(EX, HY, EX + Math.cos(a) * l, HY + Math.sin(a) * l, (u) => (u < 0.4 ? WHITE : i % 2 ? C[5] : C[6]), (u) => (u < 0.6 ? 1 : 1.6 - u));
  }
  for (let k = 0; k < 3; k++) {
    const q = fract(ph * 3 + k / 3);
    p.ring(EX, HY, 3 + 15 * ease.outCubic(q), Math.max(1, 2 * (1 - q)), q < 0.25 ? WHITE : C[5], 1.1 - q);
  }
  p.circle(EX, HY, ir + 1.5, C[4]);
  p.circle(EX, HY, ir, C[6]);
  p.circle(EX, HY, ir * 0.55, WHITE);
  p.glow(EX, HY, 40, C[5], 0.9);
  p.glow(EX, HY, 12, WHITE, 0.6);
  // a fountain of sparks thrown up and back off the end, arcing down
  cycle(t, D, 220, S * 3 + 2, (g) => g.range(0.18, 0.5), (age, life, r) => {
    const a = Math.PI * 1.5 + r.range(-1.7, 0.45), sp = r.range(70, 260), vx = Math.cos(a) * sp, vy = Math.sin(a) * sp - 30;
    const [x, y] = fly(EX, HY, vx, vy, age, 480, 2.2), [ux, uy] = flyV(vx, vy, age, 480, 2.2), k = 1 - age / life;
    if (y > -1) return;
    const head = k > 0.6 ? WHITE : k > 0.3 ? C[6] : C[5], sp2 = Math.hypot(ux, uy) || 1, len = Math.min(8, 1 + sp2 * 0.022);
    p.line(x - (ux / sp2) * len, y - (uy / sp2) * len, x, y, (u) => (u > 0.5 ? head : C[4]));
    p.glow(x, y, 3, head, 0.45 * k);
  });
  cycle(t, D, 6, S * 3 + 3, 0.3, (age, life, r) => {
    const k = Math.sin((age / life) * Math.PI);
    sparkle(p, EX + r.range(-12, 4), HY + r.range(-12, 12), 1 + 2.5 * k, C[6], C[5], 0.4 * k);
  });
  // violet vapour lifting off the end
  cycle(t, D, 7, S * 3 + 5, (g) => g.range(0.8, 1.2), (age, life, r) => {
    const q = age / life, x = EX + r.range(-8, 4) - q * 6, y = HY - 4 - q * r.range(14, 24), rad = r.range(3, 5) * (0.7 + 0.8 * q);
    p.disc(x, y, rad, C[4], (dd) => 0.28 * Math.sin(q * Math.PI) * (1 - dd * dd));
  });
}
