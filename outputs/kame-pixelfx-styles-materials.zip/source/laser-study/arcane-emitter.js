// The beam (banded across, pulses running down it, sine strands that brighten in front, a source flare with
// spinning rays, an end flare spraying rays and sparks) is adapted from Sprite Fusion's open-source energy beam
// (https://www.spritefusion.com/pixel-art-vfx/energy), MIT License, Copyright (c) 2026 Hugo Duprez.
// Derived from Patch pixelfx 5294518 (MIT); keep this attribution.
import { PAL, fit, cycle, fly, flyV, loopNoise, fract, ease, sparkle, TAU, WHITE, READY } from "../../core/index.js";
import { bayer, mote } from "../arcane/_lib.js";

const D = 1.2, HX = 15, HY = -24, L = 168, W = 6;

export const meta = {
  name: "Arcane beam upstream emitter", desc: "An isolated layer from the upstream Arcane beam.",
  tags: ["arcane", "beam"], size: [264, 100], origin: [26, 84],
  duration: D, loop: true, fps: 30, bg: "dark",
  options: { palette: ["#101734","#173665","#245bb2","#2e8cf0","#55c1ff","#98e9ff","#ddf9ff","#ffffff"], seed: 10 },
};

export function draw(p, t, o) {
  const C = fit(o.palette, 8), ph = t / D, S = o.seed, EX = HX + L;
  // the source: a flickering flare with spinning rays at the hand
  const fr = 4.2 + Math.sin(ph * TAU * 10) * 0.6;
  for (let i = 0; i < 4; i++) {
    const a = ph * TAU * 2.5 + (i * TAU) / 4, l = 7 + 3 * Math.sin(ph * TAU * 6 + i);
    p.line(HX, HY, HX + Math.cos(a) * l, HY + Math.sin(a) * l, (u) => (u < 0.5 ? WHITE : C[6]), (u) => (u < 0.6 ? 1 : 1.6 - u));
  }
  p.circle(HX, HY, fr + 1.5, C[4]);
  p.circle(HX, HY, fr, C[6]);
  p.circle(HX, HY, fr * 0.6, WHITE);
  p.glow(HX, HY, 32, C[5], 0.8);
  // energy drawn into the hand
  cycle(t, D, 10, S * 3 + 1, 0.18, (age, life, r) => {
    const a = r.range(0, TAU), dd = 16 * (1 - age / life) + 3, x = HX + Math.cos(a) * dd, y = HY + Math.sin(a) * dd;
    p.dot(x, y, age / life > 0.6 ? WHITE : C[6]);
  });

}
