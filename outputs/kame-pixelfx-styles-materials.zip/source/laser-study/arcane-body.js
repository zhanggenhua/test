// The beam (banded across, pulses running down it, sine strands that brighten in front, a source flare with
// spinning rays, an end flare spraying rays and sparks) is adapted from Sprite Fusion's open-source energy beam
// (https://www.spritefusion.com/pixel-art-vfx/energy), MIT License, Copyright (c) 2026 Hugo Duprez.
// Derived from Patch pixelfx 5294518 (MIT); keep this attribution.
import { PAL, fit, cycle, fly, flyV, loopNoise, fract, ease, sparkle, TAU, WHITE, READY } from "../../core/index.js";
import { bayer, mote } from "../arcane/_lib.js";

const D = 1.2, HX = 15, HY = -24, L = 168, W = 6;

export const meta = {
  name: "Arcane beam upstream body", desc: "An isolated layer from the upstream Arcane beam.",
  tags: ["arcane", "beam"], size: [264, 100], origin: [26, 84],
  duration: D, loop: true, fps: 30, bg: "dark",
  options: { palette: ["#101734","#173665","#245bb2","#2e8cf0","#55c1ff","#98e9ff","#ddf9ff","#ffffff"], seed: 10 },
};

export function draw(p, t, o) {
  const C = fit(o.palette, 8), ph = t / D, S = o.seed, EX = HX + L;
  // the body, built across from a white core out to a dithered violet edge, wobbling and pulsing as it goes
  const LV = [WHITE, C[6], C[5], C[4], C[3], C[2]];
  for (let d = 0; d <= L; d += 0.5) {
    const x = HX + d, w = W * (1 + 0.12 * Math.sin(d * 0.35 - ph * TAU * 8)) * Math.min(1, (d + 3) / 7);
    const pulse = fract(d * 0.025 - ph * 4) < 0.07 ? 1 : 0;
    for (let q0 = -w * 1.3; q0 <= w * 1.3; q0 += 0.5) {
      const q = Math.abs(q0) / w, y = HY + q0;
      let lv = q < 0.2 ? 0 : q < 0.4 ? 1 : q < 0.62 ? 2 : q < 0.85 ? 3 : q < 1 ? 4 : 5;
      lv = Math.max(0, lv - pulse);
      if (lv === 5 && bayer(x, y) > (1.3 - q) / 0.3) continue;
      p.px(x, y, LV[lv]);
    }
    // three strands twisting round it: bright on the near side, gone behind
    for (let s = 0; s < 3; s++) {
      const a = d * 0.17 - ph * TAU * 6 + (s * TAU) / 3, off = Math.sin(a) * w * 1.05;
      if (Math.cos(a) > -0.15) p.dot(x, HY + off, Math.cos(a) > 0.55 ? WHITE : C[6]);
    }
    if ((Math.round(d * 2) & 11) === 0) p.glow(x, HY, w * 2.2 + 4, C[5], 0.2);
  }

  // motes shed along the beam
  cycle(t, D, 16, S * 3 + 4, (g) => g.range(0.3, 0.6), (age, life, r) => {
    const q = age / life, x = HX + r.range(10, L - 10) + q * 20, y = HY + r.sign() * (W + 1 + q * r.range(4, 10));
    mote(p, x, y, 40, (y - HY) * 1.5, r.chance(0.5) ? C[6] : C[5], 0.6, 1 - q, 0.3);
  });
}
