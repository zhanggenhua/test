// Derived from Patch pixelfx 5294518 / Hugo Duprez, MIT.
import * as original from "../laser-study/arcane-impact.js";
const paint = original.draw;
export const meta = {
  ...original.meta, name: "base impact", actor: 0,
  options: { ...original.meta.options, palette: ["#101734", "#173665", "#245bb2", "#2e8cf0", "#55c1ff", "#98e9ff", "#ddf9ff", "#ffffff"] }
};
export const draw = paint;
