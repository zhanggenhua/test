// Derived from Patch pixelfx 5294518 / Hugo Duprez, MIT.
import * as original from "../arcane/spell-charge.js";
const paint = original.draw;
export const meta = {
  ...original.meta, name: "tint charge", actor: 0,
  options: { ...original.meta.options, palette: ["#071b33", "#144163", "#1c5e8a", "#288ea8", "#37bfd4", "#77e7ed", "#d2ffff", "#ffffff"] }
};
export const draw = paint;
